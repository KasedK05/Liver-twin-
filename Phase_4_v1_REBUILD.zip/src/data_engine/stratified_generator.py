import numpy as np
import torch
from pathlib import Path
from typing import Dict, List
import time
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from digital_twin.gpu_simulator import CellSimulatorGPU


class StratifiedGenerator6Class:
    """
    Generates stratified datasets for the 6-class response taxonomy.
    Uses targeted scenario pools per class with simulator's native classifier.
    """

    CLASS_NAMES = ["CVR", "BRT", "PVR", "VBR", "TRF", "SMR"]

    def __init__(self, device="cuda", batch_size=512):
        self.device = device
        self.batch_size = batch_size
        self.sim = CellSimulatorGPU(device=device)

        # Scenario pools tuned for the 6-class taxonomy
        self.scenario_pools = {
            "CVR": [
                {"drug": "entecavir", "dose": 0.8, "virus": "hbv_wildtype", "weight": 4.0},
                {"drug": "entecavir", "dose": 0.6, "virus": "hbv_wildtype", "weight": 3.0},
                {"drug": "NAC", "dose": 0.8, "virus": "viral_mild", "weight": 2.0},
                {"drug": "dexamethasone", "dose": 0.6, "virus": "hbv_wildtype", "weight": 1.5},
            ],
            "BRT": [
                {"drug": "entecavir", "dose": 0.6, "virus": "hbv_wildtype", "weight": 2.0},  # will need rotenone too
                {"drug": "bortezomib", "dose": 0.5, "virus": "hbv_wildtype", "weight": 3.0},
                {"drug": "rotenone", "dose": 0.3, "virus": "hbv_wildtype", "weight": 2.5},
                {"drug": "entecavir", "dose": 0.8, "virus": "hbv_wildtype", "weight": 1.5},  # base antiviral
            ],
            "PVR": [
                {"drug": "entecavir", "dose": 0.2, "virus": "hbv_ymdd", "weight": 3.0},
                {"drug": "entecavir", "dose": 0.3, "virus": "hbv_wildtype", "weight": 2.5},
                {"drug": None, "dose": 0.0, "virus": "hbv_ymdd", "weight": 2.0},
                {"drug": "dexamethasone", "dose": 0.3, "virus": "hbv_wildtype", "weight": 1.5},
            ],
            "VBR": [
                {"drug": "entecavir", "dose": 0.8, "virus": "hbv_ymdd", "weight": 4.0},
                {"drug": "entecavir", "dose": 0.6, "virus": "hbv_ymdd", "weight": 3.0},
                {"drug": "entecavir", "dose": 0.4, "virus": "hbv_ymdd", "weight": 2.0},
            ],
            "TRF": [
                {"drug": "rotenone", "dose": 1.0, "virus": None, "weight": 3.5},
                {"drug": "bortezomib", "dose": 1.0, "virus": None, "weight": 3.0},
                {"drug": "rotenone", "dose": 0.8, "virus": "hbv_wildtype", "weight": 2.5},
                {"drug": "bortezomib", "dose": 0.8, "virus": "hbv_ymdd", "weight": 2.0},
            ],
            "SMR": [
                {"drug": None, "dose": 0.0, "virus": "viral_mild", "weight": 3.0},
                {"drug": None, "dose": 0.0, "virus": "hbv_wildtype", "weight": 2.5},
                {"drug": None, "dose": 0.0, "virus": None, "weight": 1.5},
            ]
        }

    def _sample_scenario(self, pool_name: str) -> Dict:
        pool = self.scenario_pools[pool_name]
        weights = [s["weight"] for s in pool]
        probs = np.array(weights) / sum(weights)
        idx = np.random.choice(len(pool), p=probs)
        scenario = pool[idx].copy()
        del scenario["weight"]
        return scenario

    def generate_class(self, target_class: str, n_needed: int, max_attempts: int = 10) -> List[np.ndarray]:
        print(f"\n=== Generating {n_needed} '{target_class}' trajectories ===")
        collected = []
        total_simulated = 0

        for attempt in range(1, max_attempts + 1):
            need = n_needed - len(collected)
            if need <= 0:
                break

            current_batch_size = min(self.batch_size, max(need * 2, 512))
            batch = []
            for _ in range(current_batch_size):
                sc = self._sample_scenario(target_class)
                batch.append({"scenario": sc, "params": {}})

            trajs, times = self.sim.run(batch, t_max=24.0, dt=0.5, n_steps=49)

            # Use simulator's NEW 6-class classifier
            results = self.sim.classify_outcomes(trajs)
            total_simulated += len(batch)

            for i, res in enumerate(results):
                if res["overall"] == target_class and len(collected) < n_needed:
                    collected.append(trajs[i])

            efficiency = len(collected) / total_simulated * 100
            print(f"  Attempt {attempt:2d}: {len(collected):5d}/{n_needed} collected "
                  f"(simulated: {total_simulated:6d}, efficiency: {efficiency:4.1f}%)")

            if len(collected) >= n_needed:
                break

            if attempt >= 5 and efficiency < 10.0:
                print(f"  WARNING: Low efficiency ({efficiency:.1f}%).")

        shortfall = n_needed - len(collected)
        if shortfall > 0:
            print(f"  Shortfall: {shortfall}. Applying jitter augmentation...")
            if len(collected) > 0:
                sources = collected
                for _ in range(shortfall):
                    src = sources[np.random.randint(len(sources))]
                    noise = np.random.normal(0, 0.015, src.shape)
                    aug = np.clip(src + noise, 0.0, 1.0)
                    collected.append(aug)

        print(f"  Final: {len(collected)} {target_class} trajectories")
        return collected

    def generate(self, target_counts: Dict[str, int], output_path: str):
        print("=" * 60)
        print("STRATIFIED DATASET GENERATION — 6-CLASS TAXONOMY")
        print("=" * 60)
        print(f"Target distribution: {target_counts}")
        print(f"Total: {sum(target_counts.values())}")
        print(f"Device: {self.device} (batch={self.batch_size})")
        print("=" * 60)

        start_time = time.time()
        all_trajs = []
        all_results = []

        for class_name in self.CLASS_NAMES:
            n_needed = target_counts.get(class_name, 0)
            if n_needed == 0:
                continue
            class_trajs = self.generate_class(class_name, n_needed)

            # Re-classify to get full metadata
            results = self.sim.classify_outcomes(np.array(class_trajs))
            all_trajs.extend(class_trajs)
            all_results.extend(results)

        # Shuffle
        indices = np.random.permutation(len(all_results))
        all_trajs = [all_trajs[i] for i in indices]
        all_results = [all_results[i] for i in indices]

        trajectories = np.array(all_trajs)
        labels = np.array([r["overall"] for r in all_results])
        mechanisms = np.array([r["mechanism"] for r in all_results])
        subsystem_states = np.array([str(r["subsystems"]) for r in all_results])
        summaries = np.array([r["summary"] for r in all_results])

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        times = np.arange(49) * 0.5
        np.savez(output_path,
                 trajectories=trajectories,
                 labels=labels,
                 mechanisms=mechanisms,
                 subsystem_states=subsystem_states,
                 summaries=summaries,
                 times=times)

        elapsed = time.time() - start_time
        print("\n" + "=" * 60)
        print(f"SAVED: {output_path}")
        print(f"Shape: {trajectories.shape}")
        print(f"Time: {elapsed:.1f}s ({elapsed/60:.1f} min)")
        print(f"Throughput: {len(all_results)/elapsed:.0f} traj/s")

        print("\n--- Distribution ---")
        for cls in self.CLASS_NAMES:
            c = int((labels == cls).sum())
            pct = 100 * c / len(labels)
            print(f"  {cls:5s}: {c:6d} ({pct:5.1f}%)")

        print("\n--- Mechanisms (Top 10) ---")
        from collections import Counter
        for mech, count in Counter(mechanisms).most_common(10):
            pct = 100 * count / len(mechanisms)
            print(f"  {mech:40s}: {count:5d} ({pct:5.1f}%)")

        print("=" * 60)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--scale", choices=["10k", "50k", "200k"], required=True)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    scale_map = {
        "10k": {"CVR": 1700, "BRT": 1700, "PVR": 1700, "VBR": 1700, "TRF": 1700, "SMR": 1700},
        "50k": {"CVR": 8500, "BRT": 8500, "PVR": 8500, "VBR": 8500, "TRF": 8500, "SMR": 8500},
        "200k": {"CVR": 34000, "BRT": 34000, "PVR": 34000, "VBR": 34000, "TRF": 34000, "SMR": 34000}
    }

    gen = StratifiedGenerator6Class(device=args.device, batch_size=args.batch_size)
    output = f"data/raw/stratified_6class_{args.scale}.npz"
    gen.generate(scale_map[args.scale], output)
