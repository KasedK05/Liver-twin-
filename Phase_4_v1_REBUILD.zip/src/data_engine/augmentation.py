import numpy as np

class Augmenter:
    """Minimal jitter augmentation for rare classes."""

    def __init__(self, sigma=0.015):
        self.sigma = sigma

    def jitter(self, trajectory):
        noise = np.random.normal(0, self.sigma, trajectory.shape)
        return np.clip(trajectory + noise, 0, 1)
