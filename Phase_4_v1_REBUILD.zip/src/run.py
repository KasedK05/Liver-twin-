#!/usr/bin/env python3
"""
MASTER ENTRY POINT
Dispatches all 4 operational modes:
  1. validate  - Pre-run biological and computational checks
  2. generate  - Stratified dataset generation with train/val/test split
  3. train     - Train AI models (LSTM small, LSTM large, Transformer)
  4. infer     - Evaluate on raw test data only
  5. all       - Run full pipeline end-to-end

Usage:
  python run.py --mode validate
  python run.py --mode generate --scale 10k
  python run.py --mode train --architecture transformer
  python run.py --mode infer --model outputs/transformer/best.pt
  python run.py --mode all --scale 50k
"""

import argparse
import sys
import os
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

def main():
    parser = argparse.ArgumentParser(description="Cell Digital Twin - Master Pipeline")
    parser.add_argument("--mode", choices=["validate", "generate", "train", "infer", "all"],
                       required=True, help="Operational mode")
    parser.add_argument("--scale", choices=["1k", "10k", "50k", "200k"], default="10k",
                     help="Dataset scale for generation")
    parser.add_argument("--architecture", choices=["lstm_small", "lstm_large", "transformer", "all"],
                     default="all", help="Model architecture for training")
    parser.add_argument("--model", type=str, help="Path to model checkpoint for inference")
    parser.add_argument("--device", default="cuda", help="Device for computation")
    parser.add_argument("--debug", action="store_true", help="Debug mode (small batches)")
    args = parser.parse_args()

    if args.mode == "validate":
        from digital_twin.validators import run_validations
        success = run_validations()
        sys.exit(0 if success else 1)

    elif args.mode == "generate":
        from data_engine.stratified_generator import StratifiedGenerator6Class
        scale_map = {
            "1k": {"CVR": 170, "BRT": 170, "PVR": 170, "VBR": 170, "TRF": 170, "SMR": 170},
            "10k": {"CVR": 1700, "BRT": 1700, "PVR": 1700, "VBR": 1700, "TRF": 1700, "SMR": 1700},
            "50k": {"CVR": 8500, "BRT": 8500, "PVR": 8500, "VBR": 8500, "TRF": 8500, "SMR": 8500},
            "200k": {"CVR": 34000, "BRT": 34000, "PVR": 34000, "VBR": 34000, "TRF": 34000, "SMR": 34000}
        }
        gen = StratifiedGenerator6Class(device=args.device, batch_size=64 if args.debug else 512)
        gen.generate(scale_map[args.scale], f"data/raw/stratified_6class_{args.scale}.npz")

    elif args.mode == "train":
        print("Training mode - use train_hierarchical.py directly for now")
        print("Example: python train_hierarchical.py --dataset data/train/trajectories.npz --architecture transformer")

    elif args.mode == "infer":
        print("Inference mode - use inference/predictor.py directly")
        print("Example: python inference/predictor.py --model outputs/transformer/best.pt --test data/test/trajectories.npz")

    elif args.mode == "all":
        print("=" * 60)
        print("FULL PIPELINE EXECUTION")
        print("=" * 60)
        print("Step 1: Validation")
        from digital_twin.validators import run_validations
        if not run_validations():
            print("VALIDATION FAILED - Aborting pipeline")
            sys.exit(1)

        print("\nStep 2: Dataset Generation")
        from data_engine.stratified_generator import StratifiedGenerator6Class
        scale_map = {
            "1k": {"CVR": 170, "BRT": 170, "PVR": 170, "VBR": 170, "TRF": 170, "SMR": 170},
            "10k": {"CVR": 1700, "BRT": 1700, "PVR": 1700, "VBR": 1700, "TRF": 1700, "SMR": 1700},
            "50k": {"CVR": 8500, "BRT": 8500, "PVR": 8500, "VBR": 8500, "TRF": 8500, "SMR": 8500},
            "200k": {"CVR": 34000, "BRT": 34000, "PVR": 34000, "VBR": 34000, "TRF": 34000, "SMR": 34000}
        }
        gen = StratifiedGenerator6Class(device=args.device, batch_size=64 if args.debug else 512)
        gen.generate(scale_map[args.scale], f"data/raw/stratified_6class_{args.scale}.npz")

        print("\nStep 3: Dataset Splitting")
        from data_engine.dataset_splitter import split_dataset
        split_dataset(f"data/raw/stratified_6class_{args.scale}.npz", train_ratio=0.7, val_ratio=0.15, test_ratio=0.15)

        print("\nStep 4: Training")
        print("Run training scripts manually for each architecture")

        print("\nStep 5: Inference")
        print("Run inference scripts manually on data/test/")

        print("\n" + "=" * 60)
        print("PIPELINE COMPLETE")
        print("=" * 60)

if __name__ == "__main__":
    main()
