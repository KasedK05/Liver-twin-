import numpy as np
import torch

def compute_effective_weights(labels, num_classes, beta=0.999):
    counts = np.bincount(labels, minlength=num_classes)
    effective_num = 1.0 - np.power(beta, counts)
    weights = (1.0 - beta) / effective_num
    weights = weights / weights.sum() * num_classes
    return torch.FloatTensor(weights)
