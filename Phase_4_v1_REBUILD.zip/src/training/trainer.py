import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np

class CellTrajectoryDataset(Dataset):
    def __init__(self, trajectories, labels, mechanisms, mech_to_idx, 
                 observation_ratio=0.5, add_noise=True):
        self.trajectories = trajectories.astype(np.float32)
        self.labels = labels
        self.mechanisms = mechanisms
        self.mech_to_idx = mech_to_idx
        self.observation_ratio = observation_ratio
        self.add_noise = add_noise

        self.overall_to_idx = {cls: i for i, cls in enumerate(sorted(set(labels)))}
        self.full_times = np.arange(49) * 0.5

    def __len__(self):
        return len(self.trajectories)

    def __getitem__(self, idx):
        traj = self.trajectories[idx]
        if self.add_noise:
            noise = np.random.normal(0, 0.01, traj.shape)
            traj = np.clip(traj + noise, 0, 1)

        n_input = int(49 * self.observation_ratio)
        x = traj[:n_input]
        t = self.full_times[:n_input].astype(np.float32)

        overall_label = self.overall_to_idx[self.labels[idx]]
        mechanism_label = self.mech_to_idx.get(self.mechanisms[idx], 0)

        # Subsystem health from final state
        final = traj[-1]
        subsystem_targets = np.array([
            np.mean(final[0:4]), np.mean(final[4:9]), np.mean(final[9:13]),
            np.mean(final[13:17]), np.mean(final[17:22]), np.mean(final[22:28]),
            np.mean(final[28:32])
        ], dtype=np.float32)

        return {
            'x': torch.from_numpy(x),
            't': torch.from_numpy(t),
            'overall': torch.tensor(overall_label, dtype=torch.long),
            'mechanism': torch.tensor(mechanism_label, dtype=torch.long),
            'subsystems': torch.from_numpy(subsystem_targets),
        }

def collate_fn(batch):
    max_len = max(item['x'].shape[0] for item in batch)
    x_padded, t_padded, masks = [], [], []

    for item in batch:
        x, t = item['x'], item['t']
        seq_len = x.shape[0]
        if seq_len < max_len:
            pad_len = max_len - seq_len
            x_padded.append(torch.cat([x, torch.zeros(pad_len, x.shape[1])], dim=0))
            t_padded.append(torch.cat([t, torch.zeros(pad_len)], dim=0))
            masks.append(torch.cat([torch.zeros(seq_len), torch.ones(pad_len)], dim=0).bool())
        else:
            x_padded.append(x)
            t_padded.append(t)
            masks.append(torch.zeros(seq_len).bool())

    return {
        'x': torch.stack(x_padded),
        't': torch.stack(t_padded),
        'mask': torch.stack(masks),
        'overall': torch.stack([item['overall'] for item in batch]),
        'mechanism': torch.stack([item['mechanism'] for item in batch]),
        'subsystems': torch.stack([item['subsystems'] for item in batch]),
    }

class Trainer:
    def __init__(self, model, device, class_weights=None, lr=1e-3):
        self.model = model.to(device)
        self.device = device
        self.optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=50)

        self.overall_criterion = nn.CrossEntropyLoss()
        self.mechanism_criterion = nn.CrossEntropyLoss(weight=class_weights)
        self.subsystem_criterion = nn.MSELoss()

    def train_epoch(self, dataloader, lambda_overall=0.5, lambda_mechanism=0.3, lambda_subsystem=0.2):
        self.model.train()
        total_loss = 0
        n_batches = 0

        for batch in dataloader:
            x = batch['x'].to(self.device)
            t = batch['t'].to(self.device)
            mask = batch['mask'].to(self.device)
            y_overall = batch['overall'].to(self.device)
            y_mech = batch['mechanism'].to(self.device)
            y_sub = batch['subsystems'].to(self.device)

            self.optimizer.zero_grad()
            overall_logits, mech_logits, sub_preds, _ = self.model(x, t, mask)

            loss = (lambda_overall * self.overall_criterion(overall_logits, y_overall) +
                    lambda_mechanism * self.mechanism_criterion(mech_logits, y_mech) +
                    lambda_subsystem * self.subsystem_criterion(sub_preds, y_sub))

            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()

            total_loss += loss.item()
            n_batches += 1

        self.scheduler.step()
        return total_loss / n_batches

    def evaluate(self, dataloader):
        self.model.eval()
        overall_correct = 0
        mech_correct = 0
        total = 0

        with torch.no_grad():
            for batch in dataloader:
                x = batch['x'].to(self.device)
                t = batch['t'].to(self.device)
                mask = batch['mask'].to(self.device)
                y_overall = batch['overall'].to(self.device)
                y_mech = batch['mechanism'].to(self.device)

                overall_logits, mech_logits, _, _ = self.model(x, t, mask)
                overall_pred = overall_logits.argmax(dim=1)
                mech_pred = mech_logits.argmax(dim=1)

                overall_correct += (overall_pred == y_overall).sum().item()
                mech_correct += (mech_pred == y_mech).sum().item()
                total += y_overall.size(0)

        return {
            'overall_acc': overall_correct / total,
            'mechanism_acc': mech_correct / total,
        }
