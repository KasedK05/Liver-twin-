from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, brier_score_loss
import numpy as np

def compute_metrics(y_true, y_pred, y_prob=None):
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'f1_macro': f1_score(y_true, y_pred, average='macro', zero_division=0),
    }
    if y_prob is not None:
        try:
            metrics['auc_roc'] = roc_auc_score(y_true, y_prob, multi_class='ovr', average='macro')
        except:
            metrics['auc_roc'] = 0.0
        try:
            metrics['brier_score'] = brier_score_loss(y_true, y_prob)
        except:
            metrics['brier_score'] = 0.0
    return metrics
