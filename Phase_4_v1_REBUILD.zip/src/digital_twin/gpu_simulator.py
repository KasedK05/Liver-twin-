import torch
import numpy as np
from .perturbation import Perturbation
from .coupling import CouplingEngine

class CellSimulatorGPU:
    """GPU-accelerated cell simulator with 7 subsystems."""

    def __init__(self, device="cuda"):
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.perturbation = Perturbation()
        self.coupling = CouplingEngine()

    def _init_state(self, batch_size):
        """Initialize batched state tensor (batch, 32)."""
        s = torch.zeros((batch_size, 32), device=self.device)
        # Genetic: 0-3
        s[:, 0] = torch.normal(0.95, 0.02, (batch_size,), device=self.device)
        s[:, 1] = torch.normal(0.70, 0.03, (batch_size,), device=self.device)
        s[:, 2] = torch.normal(0.80, 0.02, (batch_size,), device=self.device)
        s[:, 3] = torch.normal(0.50, 0.05, (batch_size,), device=self.device)
        # Energy: 4-8
        s[:, 4] = torch.normal(0.90, 0.03, (batch_size,), device=self.device)
        s[:, 5] = torch.normal(0.85, 0.03, (batch_size,), device=self.device)
        s[:, 6] = torch.normal(0.88, 0.02, (batch_size,), device=self.device)
        s[:, 7] = torch.normal(0.30, 0.05, (batch_size,), device=self.device)
        s[:, 8] = torch.normal(0.95, 0.02, (batch_size,), device=self.device)
        # Protein: 9-12
        s[:, 9] = torch.normal(0.60, 0.03, (batch_size,), device=self.device)
        s[:, 10] = torch.normal(0.05, 0.01, (batch_size,), device=self.device)
        s[:, 11] = torch.normal(0.05, 0.01, (batch_size,), device=self.device)
        s[:, 12] = torch.normal(0.40, 0.03, (batch_size,), device=self.device)
        # Signaling: 13-16
        s[:, 13] = torch.normal(0.50, 0.05, (batch_size,), device=self.device)
        s[:, 14] = torch.normal(0.10, 0.02, (batch_size,), device=self.device)
        s[:, 15] = torch.normal(0.40, 0.03, (batch_size,), device=self.device)
        s[:, 16] = torch.normal(0.10, 0.02, (batch_size,), device=self.device)
        # Membrane: 17-21
        s[:, 17] = torch.normal(0.90, 0.02, (batch_size,), device=self.device)
        s[:, 18] = torch.normal(0.85, 0.03, (batch_size,), device=self.device)
        s[:, 19] = torch.normal(0.10, 0.02, (batch_size,), device=self.device)
        s[:, 20] = torch.normal(0.70, 0.03, (batch_size,), device=self.device)
        s[:, 21] = torch.normal(0.60, 0.03, (batch_size,), device=self.device)
        # Defense: 22-27
        s[:, 22] = torch.normal(0.10, 0.02, (batch_size,), device=self.device)
        s[:, 23] = torch.normal(0.60, 0.03, (batch_size,), device=self.device)
        s[:, 24] = torch.normal(0.20, 0.03, (batch_size,), device=self.device)
        s[:, 25] = torch.normal(0.05, 0.01, (batch_size,), device=self.device)
        s[:, 26] = torch.normal(0.05, 0.01, (batch_size,), device=self.device)
        s[:, 27] = 0.0
        # Waste: 28-31
        s[:, 28] = torch.normal(0.20, 0.03, (batch_size,), device=self.device)
        s[:, 29] = torch.normal(0.70, 0.03, (batch_size,), device=self.device)
        s[:, 30] = torch.normal(0.10, 0.02, (batch_size,), device=self.device)
        s[:, 31] = torch.normal(0.05, 0.01, (batch_size,), device=self.device)
        return torch.clamp(s, 0, 1)

    def _update(self, s, dt, c, d):
        """Vectorized update of all subsystems."""
        # Genetic
        damage = 0.05 * c["ros"] + 0.03 * c["viral_load"] + d["dna_damage"]
        repair = 0.10 * c["dna_repair_activity"]
        s[:, 0] += dt * (repair - damage)
        tx_drive = 0.5 * s[:, 0] + 0.3 * c["atp"]
        s[:, 1] += dt * (0.05 * (tx_drive - s[:, 1]) - d["tx_suppress"])
        chrom_stress = 0.03 * c["ros"]
        chrom_relax = 0.02 * (1 - s[:, 2])
        s[:, 2] += dt * (chrom_relax - chrom_stress)
        cycle_speed = 0.02 * s[:, 1] * c["atp"]
        arrest = (s[:, 0] < 0.3).float()
        s[:, 3] += dt * (cycle_speed * (1 - arrest))
        s[:, 3] = s[:, 3] % 1.0

        # Energy
        atp_prod = 0.05 * s[:, 6] * s[:, 8] * (1 + d["atp_boost"])
        atp_demand = c["atp_demand"]
        atp_decay = 0.02 * s[:, 4]
        s[:, 4] += dt * (atp_prod - atp_demand - atp_decay)
        nad_shift = 0.01 * (s[:, 7] - 0.3) - 0.02 * c["ros"]
        s[:, 5] += dt * nad_shift
        mito_damage = d["mito_damage"] + 0.1 * c["ros"]
        mito_recovery = 0.03 * (1 - s[:, 6]) * s[:, 4]
        s[:, 6] += dt * (mito_recovery - mito_damage)
        glyco_drive = (s[:, 6] < 0.4).float() * 0.5
        s[:, 7] += dt * (0.02 * glyco_drive - 0.01 * (s[:, 7] - 0.3))
        o2_consump = 0.02 * s[:, 6] + 0.01 * s[:, 7]
        s[:, 8] += dt * (0.05 * (0.95 - s[:, 8]) - o2_consump)

        # Protein
        trans_capacity = 0.5 * c["atp"]
        s[:, 9] += dt * (0.05 * (trans_capacity - s[:, 9]) - d["trans_inhibit"])
        upr_trigger = ((s[:, 11] > 0.4) | (d["proteasome_inhibit"] > 0.5)).float()
        upr_resolve = 0.1 * s[:, 10] * c["atp"]
        s[:, 10] += dt * (0.3 * upr_trigger - upr_resolve)
        agg_form = 0.05 * (1 - s[:, 10]) * s[:, 9]
        agg_clear = 0.10 * c["autophagy_flux"]
        s[:, 11] += dt * (agg_form - agg_clear)
        sec_load = 0.03 * s[:, 9]
        sec_capacity = 0.02 * c["atp"]
        s[:, 12] += dt * (sec_load - sec_capacity)

        # Signaling
        mtor_drive = 0.5 * c["atp"] + 0.3 * s[:, 15]
        mtor_inhibit = 0.2 * c["ros"] + d.get("mtor_inhibit", torch.zeros_like(s[:, 13]))
        s[:, 13] += dt * (0.05 * (mtor_drive - s[:, 13]) - mtor_inhibit)
        p53_trigger = ((c["dna_damage_signal"] > 0.5) | (c["ros"] > 0.6)).float()
        p53_decay = 0.08 * s[:, 14]
        s[:, 14] += dt * (0.4 * p53_trigger - p53_decay)
        gf_decay = 0.05 * s[:, 15]
        s[:, 15] += dt * (-gf_decay)
        cyto_drive = 0.3 * c["inflammasome_activity"] + 0.2 * c["viral_load"]
        s[:, 16] += dt * (0.05 * cyto_drive - 0.03 * s[:, 16] - d["cytokine_suppress"])

        # Membrane
        mem_damage = 0.05 * c["ros"] + 0.03 * c["viral_load"] + d["mem_damage"]
        mem_repair = 0.04 * c["atp"]
        s[:, 17] += dt * (mem_repair - mem_damage)
        pump_capacity = 0.5 * c["atp"]
        leak = 0.03 * (1 - s[:, 17])
        s[:, 18] += dt * (0.05 * (pump_capacity - s[:, 18]) - leak)
        ca_influx = 0.1 * (1 - s[:, 18]) + d.get("ca_influx", torch.zeros_like(s[:, 19]))
        ca_efflux = 0.08 * c["atp"]
        s[:, 19] += dt * (ca_influx - ca_efflux)
        uptake_drive = 0.4 * s[:, 17]
        uptake_inhibit = 0.05 * s[:, 16]
        s[:, 20] += dt * (0.03 * (uptake_drive - s[:, 20]) - uptake_inhibit)
        ves_drive = 0.3 * c["atp"]
        ves_disrupt = 0.04 * c["aggregates"]
        s[:, 21] += dt * (0.03 * (ves_drive - s[:, 21]) - ves_disrupt)

        # Defense
        s[:, 27] = d["viral_load"]
        ros_gen = 0.05 * c["metabolic_load"] + d["ros_boost"]
        ros_scav = 0.10 * s[:, 23] * s[:, 22]
        s[:, 22] += dt * (ros_gen - ros_scav)
        aod_boost = d["aod_boost"]
        aod_exhaust = 0.05 * s[:, 22]
        s[:, 23] += dt * (0.02 * aod_boost - aod_exhaust)
        repair_trigger = (s[:, 22] > 0.4).float()
        repair_cost = 0.02 * s[:, 24]
        s[:, 24] += dt * (0.3 * repair_trigger - repair_cost)
        inflam_trigger = ((s[:, 22] > 0.5) & (s[:, 23] < 0.3)).float()
        s[:, 25] += dt * (0.4 * inflam_trigger - 0.1 * s[:, 25])
        ifn_trigger = s[:, 27] * (1 - d["ifn_suppress"])
        ifn_decay = 0.05 * s[:, 26]
        s[:, 26] += dt * (0.2 * ifn_trigger - ifn_decay)

        # Waste
        auto_drive = ((c["ampk"] > 0.5) | (c["mtor"] < 0.3)).float()
        auto_block = d.get("autophagy_block", torch.zeros_like(s[:, 28]))
        s[:, 28] += dt * (0.3 * auto_drive - 0.1 * s[:, 28] - auto_block)
        ph_shift = 0.02 * (1 - s[:, 28]) + 0.01 * c["ros"]
        ph_recover = 0.03 * (0.7 - s[:, 29])
        s[:, 29] += dt * (ph_recover - ph_shift)
        waste_prod = 0.03 * c["metabolic_load"]
        waste_clear = 0.08 * s[:, 28] * s[:, 29]
        s[:, 30] += dt * (waste_prod - waste_clear)
        lipo_form = 0.01 * s[:, 30] * (1 - s[:, 28])
        s[:, 31] += dt * lipo_form

        return torch.clamp(s, 0, 1)

    def run(self, batch_info, t_max=24.0, dt=0.5, n_steps=49):
        n = len(batch_info)
        s = self._init_state(n)
        trajectories = torch.zeros((n, n_steps, 32), device=self.device)

        for step in range(n_steps):
            c = self.coupling.compute(s)
            scenario = batch_info[0]["scenario"]
            d = self._apply_perturbation(
                scenario.get("drug"), 
                scenario.get("dose", 0.0), 
                scenario.get("virus"), 
                n
            )
            s = self._update(s, dt, c, d)
            trajectories[:, step, :] = s

        return trajectories.cpu().numpy(), np.arange(n_steps) * dt

    def _apply_perturbation(self, drug, dose, virus, batch_size):
        d = {}
        drug_info = self.perturbation.drug_lib.get(drug, {})
        virus_info = self.perturbation.virus_lib.get(virus, {})

        all_keys = ["atp_boost", "tx_suppress", "viral_replication_factor", "aod_boost",
                    "cytokine_suppress", "ifn_suppress", "ros_boost", "mito_damage",
                    "proteasome_inhibit", "trans_inhibit", "dna_damage", "mem_damage",
                    "viral_load", "ca_influx", "autophagy_block", "mtor_inhibit", "growth_factor"]
        for k in all_keys:
            d[k] = 0.0

        if drug_info.get("class") == "antiviral":
            d["atp_boost"] = 0.1 * dose
            d["tx_suppress"] = 0.05 * dose
            d["viral_replication_factor"] = max(0, 1 - 0.8 * dose)
        elif drug_info.get("class") == "anti-inflammatory":
            d["aod_boost"] = 0.3 * dose
            d["cytokine_suppress"] = 0.4 * dose
            d["ifn_suppress"] = 0.1 * dose
        elif drug_info.get("class") == "antioxidant":
            d["aod_boost"] = 0.5 * dose
            d["ros_boost"] = -0.2 * dose
        elif drug_info.get("class") == "mito_toxin":
            d["mito_damage"] = 0.4 * dose
            d["atp_boost"] = -0.3 * dose
        elif drug_info.get("class") == "proteasome_inhibitor":
            d["proteasome_inhibit"] = 0.6 * dose
            d["trans_inhibit"] = 0.1 * dose

        rep = virus_info.get("replication_rate", 0.0)
        cpe = virus_info.get("cytopathic_effect", 0.0)
        d["ros_boost"] = d.get("ros_boost", 0) + 0.2 * rep
        d["dna_damage"] = 0.1 * rep
        d["mem_damage"] = 0.15 * cpe
        d["viral_load"] = rep
        d["ifn_suppress"] = d.get("ifn_suppress", 0) + 0.3 * virus_info.get("interferon_antagonism", 0)

        for k in d:
            d[k] = torch.full((batch_size,), d[k], device=self.device, dtype=torch.float32)
        return d

    def classify_outcomes(self, trajectories):
        """
        6-class response taxonomy classification.
        Returns list of dicts with 'overall', 'mechanism', 'subsystems', 'summary'.
        """
        n = trajectories.shape[0]
        results = []

        for i in range(n):
            traj = trajectories[i]
            final = traj[-1]

            viral_load = final[27]
            atp = final[4]
            mito = final[6]
            upr = final[10]
            aggregates = final[11]
            interferon = final[26]
            ros = final[22]
            aod = final[23]
            dna = final[0]
            membrane = final[17]
            autophagy = final[28]
            transcription = final[1]
            inflammasome = final[25]

            viral_trend = np.polyfit(np.arange(49), traj[:, 27], 1)[0]
            viral_mid = traj[24, 27]

            # Subsystem health scores
            genetic_health = 0.5 * dna + 0.3 * transcription + 0.2 * final[2]
            energy_health = 0.3 * atp + 0.2 * final[5] + 0.2 * mito + 0.2 * final[8] + 0.1 * final[7]
            protein_health = 0.4 * final[9] + 0.3 * (1 - upr) + 0.3 * (1 - aggregates)
            signaling_health = 0.3 * final[13] + 0.3 * (1 - final[14]) + 0.2 * final[15] + 0.2 * (1 - final[16])
            membrane_health = 0.3 * membrane + 0.2 * final[18] + 0.2 * (1 - final[19]) + 0.2 * final[20] + 0.1 * final[21]
            defense_health = 0.3 * (1 - ros) + 0.3 * aod + 0.2 * final[24] + 0.2 * (1 - inflammasome)
            waste_health = 0.3 * autophagy + 0.3 * final[29] + 0.2 * (1 - final[30]) + 0.2 * (1 - final[31])

            subsystem_health = {
                "genetic": genetic_health, "energy": energy_health, "protein": protein_health,
                "signaling": signaling_health, "membrane": membrane_health,
                "defense": defense_health, "waste": waste_health
            }
            weakest = min(subsystem_health, key=subsystem_health.get)
            weakest_score = subsystem_health[weakest]

            # Class 5: TRF (Treatment-Related Failure)
            if atp < 0.10 or mito < 0.10 or membrane < 0.10:
                if viral_load < 0.30:
                    mechanism = f"TRF_{weakest}_toxicity"
                    results.append({"overall": "TRF", "mechanism": mechanism, "subsystems": subsystem_health,
                                    "summary": f"TRF: Drug toxicity death. Primary: {weakest} ({weakest_score:.2f}). Viral={viral_load:.2f}"})
                    continue
            if aggregates > 0.50 and upr > 0.60 and viral_load < 0.30:
                results.append({"overall": "TRF", "mechanism": "TRF_proteasome_toxicity", "subsystems": subsystem_health,
                                "summary": f"TRF: Proteasome inhibition death. UPR={upr:.2f}"})
                continue

            # Class 6: SMR (Spontaneous Recovery)
            if viral_load < 0.05 and interferon > 0.50 and autophagy > 0.40:
                if atp > 0.50 and ros < 0.40 and dna > 0.60:
                    results.append({"overall": "SMR", "mechanism": "SMR_innate_immunity", "subsystems": subsystem_health,
                                    "summary": f"SMR: Natural clearance. IFN={interferon:.2f}, autophagy={autophagy:.2f}"})
                    continue

            # Class 4: VBR (Virological Breakthrough)
            if viral_mid < 0.20 and viral_load > 0.30 and viral_trend > 0.005:
                results.append({"overall": "VBR", "mechanism": "VBR_resistance_emergence", "subsystems": subsystem_health,
                                "summary": f"VBR: Viral rebound {viral_mid:.2f} -> {viral_load:.2f}"})
                continue

            # Class 1: CVR (Complete Virological Response)
            if viral_load < 0.05 and atp > 0.60 and mito > 0.60 and ros < 0.30:
                if dna > 0.70 and upr < 0.30 and aggregates < 0.20 and membrane > 0.60:
                    results.append({"overall": "CVR", "mechanism": "CVR_antiviral_suppression", "subsystems": subsystem_health,
                                    "summary": f"CVR: Complete response. All systems homeostatic."})
                    continue

            # Class 2: BRT (Biochemical Response with Toxicity)
            if viral_load < 0.10:
                if atp < 0.40 or mito < 0.40 or upr > 0.50 or aggregates > 0.40 or ros > 0.50:
                    mechanism = f"BRT_{weakest}_stress"
                    results.append({"overall": "BRT", "mechanism": mechanism, "subsystems": subsystem_health,
                                    "summary": f"BRT: Viral suppressed but toxicity in {weakest}."})
                    continue

            # Class 3: PVR (Partial Virological Response)
            if 0.05 < viral_load < 0.40:
                if atp < 0.50 or ros > 0.40 or dna < 0.60 or inflammasome > 0.40:
                    mechanism = f"PVR_{weakest}_stress"
                    results.append({"overall": "PVR", "mechanism": mechanism, "subsystems": subsystem_health,
                                    "summary": f"PVR: Partial suppression ({viral_load:.2f}). Chronic stress in {weakest}."})
                    continue

            # Fallbacks
            if viral_load < 0.05:
                results.append({"overall": "CVR", "mechanism": "CVR_minor_stress", "subsystems": subsystem_health,
                                "summary": "CVR: Minor stress, defaulting to complete response."})
                continue

            if viral_load < 0.50 and atp > 0.40 and membrane > 0.30:
                results.append({"overall": "PVR", "mechanism": "PVR_stable_persistence", "subsystems": subsystem_health,
                                "summary": f"PVR: Stable persistence. Viral={viral_load:.2f}"})
                continue

            if atp < 0.10 or membrane < 0.10:
                results.append({"overall": "TRF", "mechanism": "TRF_viral_progression", "subsystems": subsystem_health,
                                "summary": f"TRF: Death from viral progression. Viral={viral_load:.2f}"})
                continue

            results.append({"overall": "PVR", "mechanism": "PVR_unclassified", "subsystems": subsystem_health,
                            "summary": f"PVR: Unclassified. Viral={viral_load:.2f}, ATP={atp:.2f}"})

        return results
