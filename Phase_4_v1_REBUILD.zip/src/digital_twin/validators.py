import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import numpy as np
from .gpu_simulator import CellSimulatorGPU

def run_validations():
    print("=" * 60)
    print("DIGITAL TWIN VALIDATION SUITE")
    print("=" * 60)
    sim = CellSimulatorGPU(device="cpu")
    all_pass = True

    checks = [
        ("Baseline stability", lambda: _check_baseline(sim)),
        ("Antiviral efficacy", lambda: _check_antiviral(sim)),
        ("Temporal ordering", lambda: _check_temporal(sim)),
        ("Mito toxin collapse", lambda: _check_mito_toxin(sim)),
        ("DNA repair activation", lambda: _check_dna_repair(sim)),
        ("UPR activation", lambda: _check_upr(sim)),
        ("Membrane damage", lambda: _check_membrane(sim)),
        ("Autophagy compensation", lambda: _check_autophagy(sim)),
        ("p53 activation", lambda: _check_p53(sim)),
        ("6-class presence", lambda: _check_six_classes(sim)),
    ]

    for name, check_fn in checks:
        try:
            status, msg = check_fn()
            print(f"[{status}] {name}: {msg}")
            all_pass &= (status == "PASS")
        except Exception as e:
            print(f"[FAIL] {name}: Exception - {e}")
            all_pass = False

    print("=" * 60)
    print("ALL PASSED" if all_pass else "SOME CHECKS FAILED")
    print("=" * 60)
    return all_pass

def _run_scenario(sim, drug, dose, virus, n=10):
    batch = [{"scenario": {"drug": drug, "dose": dose, "virus": virus}, "params": {}} for _ in range(n)]
    traj, _ = sim.run(batch, t_max=24.0, dt=0.5, n_steps=49)
    return traj

def _check_baseline(sim):
    traj = _run_scenario(sim, None, 0.0, None)
    atp_final = traj[0, :, 4].mean()
    return ("PASS", f"ATP={atp_final:.3f}") if atp_final > 0.5 else ("FAIL", f"ATP={atp_final:.3f} < 0.5")

def _check_antiviral(sim):
    traj = _run_scenario(sim, "entecavir", 0.8, "hbv_wildtype")
    atp_treat = traj[0, :, 4].mean()
    return ("PASS", f"ATP={atp_treat:.3f}") if atp_treat > 0.5 else ("FAIL", f"ATP={atp_treat:.3f}")

def _check_temporal(sim):
    traj = _run_scenario(sim, None, 0.0, "hbv_wildtype")
    ros = traj[0, :, 22]
    ifn = traj[0, :, 26]
    t_ros = np.argmax(ros > 0.3) * 0.5 if np.any(ros > 0.3) else 999
    t_ifn = np.argmax(ifn > 0.3) * 0.5 if np.any(ifn > 0.3) else 999
    return ("PASS", f"ROS@{t_ros:.1f}h, IFN@{t_ifn:.1f}h") if t_ros < t_ifn else ("FAIL", f"ROS@{t_ros:.1f}h >= IFN@{t_ifn:.1f}h")

def _check_mito_toxin(sim):
    traj = _run_scenario(sim, "rotenone", 1.0, None)
    atp_end = traj[0, -1, 4]
    mito_end = traj[0, -1, 6]
    return ("PASS", f"ATP={atp_end:.3f}, Mito={mito_end:.3f}") if atp_end < 0.1 else ("FAIL", f"ATP={atp_end:.3f} >= 0.1")

def _check_dna_repair(sim):
    traj = _run_scenario(sim, None, 0.0, "hbv_ymdd")
    repair = traj[0, :, 24]
    return ("PASS", f"max={repair.max():.3f}") if repair.max() > 0.15 else ("FAIL", f"max={repair.max():.3f}")

def _check_upr(sim):
    traj = _run_scenario(sim, "bortezomib", 1.0, None)
    upr = traj[0, :, 10]
    return ("PASS", f"max={upr.max():.3f}") if upr.max() > 0.5 else ("FAIL", f"max={upr.max():.3f}")

def _check_membrane(sim):
    traj = _run_scenario(sim, None, 0.0, "adenovirus_5")
    mem = traj[0, :, 17]
    return ("PASS", f"min={mem.min():.3f}") if mem.min() < 0.5 else ("FAIL", f"min={mem.min():.3f}")

def _check_autophagy(sim):
    traj = _run_scenario(sim, "rotenone", 0.5, None)
    auto = traj[0, :, 28]
    return ("PASS", f"max={auto.max():.3f}") if auto.max() > 0.15 else ("FAIL", f"max={auto.max():.3f}")

def _check_p53(sim):
    traj = _run_scenario(sim, None, 0.0, "hbv_ymdd")
    p53 = traj[0, :, 14]
    return ("PASS", f"max={p53.max():.3f}") if p53.max() > 0.5 else ("FAIL", f"max={p53.max():.3f}")

def _check_six_classes(sim):
    # Test multiple scenarios to get all 6 classes
    scenarios = [
        ("entecavir", 0.8, "hbv_wildtype"),   # CVR
        ("bortezomib", 0.5, "hbv_wildtype"),   # BRT
        ("entecavir", 0.2, "hbv_ymdd"),        # PVR
        ("entecavir", 0.8, "hbv_ymdd"),         # VBR
        ("rotenone", 1.0, None),                # TRF
        (None, 0.0, "viral_mild"),               # SMR
    ]
    all_results = []
    for drug, dose, virus in scenarios:
        traj = _run_scenario(sim, drug, dose, virus, n=20)
        results = sim.classify_outcomes(traj)
        all_results.extend(results)

    counts = {}
    for r in all_results:
        cls = r["overall"]
        counts[cls] = counts.get(cls, 0) + 1

    required = ["CVR", "BRT", "PVR", "VBR", "TRF", "SMR"]
    missing = [c for c in required if counts.get(c, 0) == 0]

    if missing:
        return ("FAIL", f"Missing: {missing}. Found: {counts}")
    return ("PASS", f"All 6 classes present: {counts}")
